const chatForm = document.getElementById('chatForm');
const userInput = document.getElementById('userInput');
const chatContainer = document.getElementById('chatContainer');
const newChatBtn = document.getElementById('newChatBtn');
const clearChatBtn = document.getElementById('clearChatBtn');

const WEBHOOK_URL = 'https://97-266.n8n.dignityhost.com/webhook/235fc630-6050-4a34-97b0-6188a3aefc98';
let sessionId = generateSessionId();

// Helper to generate a random session ID
function generateSessionId() {
    return 'session-' + Math.random().toString(36).substr(2, 9);
}

// Ensure smooth scroll to bottom
function scrollToBottom() {
    chatContainer.scrollTo({
        top: chatContainer.scrollHeight,
        behavior: 'smooth'
    });
}

// Add a message to the UI
function addMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender);

    const avatarDiv = document.createElement('div');
    avatarDiv.classList.add('avatar');
    avatarDiv.innerHTML = sender === 'user' ? "<i class='bx bx-user'></i>" : "<i class='bx bx-bot'></i>";

    const bubbleDiv = document.createElement('div');
    bubbleDiv.classList.add('bubble');

    // Simple markdown parsing for bold text
    const formattedText = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
    bubbleDiv.innerHTML = `<p>${formattedText}</p>`;

    messageDiv.appendChild(avatarDiv);
    messageDiv.appendChild(bubbleDiv);
    chatContainer.appendChild(messageDiv);

    scrollToBottom();
}

// Show a loading indicator
function showLoading() {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', 'bot', 'loading-msg');

    const avatarDiv = document.createElement('div');
    avatarDiv.classList.add('avatar');
    avatarDiv.innerHTML = "<i class='bx bx-bot'></i>";

    const bubbleDiv = document.createElement('div');
    bubbleDiv.classList.add('bubble');
    bubbleDiv.innerHTML = `
        <div class="loading-dots">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
        </div>
    `;

    messageDiv.appendChild(avatarDiv);
    messageDiv.appendChild(bubbleDiv);
    chatContainer.appendChild(messageDiv);

    scrollToBottom();
    return messageDiv;
}

// Handle Form Submission
chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const text = userInput.value.trim();
    if (!text) return;

    // 1. Show user message
    addMessage(text, 'user');
    userInput.value = '';

    // 2. Show loading animation
    const loadingEl = showLoading();

    // 3. Send Request to N8N Webhook
    try {
        const response = await fetch(WEBHOOK_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                chatInput: text,
                sessionId: sessionId
            })
        });

        const data = await response.json();

        // Remove loading 
        loadingEl.remove();

        // Check if output exists. Usually n8n agent returns {"output": "message"} or just raw string
        // The webhook responds according to respondNode configuration
        let botReply = "I couldn't process that.";
        if (data && data.output) {
            botReply = data.output;
        } else if (typeof data === 'string') {
            botReply = data;
        } else if (data && data.message) { // Fallback just in case
            botReply = data.message;
        } else {
            botReply = JSON.stringify(data);
        }

        addMessage(botReply, 'bot');

    } catch (error) {
        console.error('Webhook error:', error);
        loadingEl.remove();
        addMessage(`*Connection Error:* The AI service is currently unreachable.`, 'bot');
    }
});

// Reset Chat Session
const resetChat = () => {
    // Keep only the first welcome message
    const welcomeMessage = chatContainer.firstElementChild;
    chatContainer.innerHTML = '';
    if (welcomeMessage) chatContainer.appendChild(welcomeMessage);

    sessionId = generateSessionId();
};

newChatBtn.addEventListener('click', resetChat);
clearChatBtn.addEventListener('click', resetChat);
