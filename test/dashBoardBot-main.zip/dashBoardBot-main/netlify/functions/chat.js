const { createClient } = require('@supabase/supabase-js');

// ── SUPABASE CONFIG ──
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://tscpygroiqvulpughnwf.supabase.co';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRzY3B5Z3JvaXF2dWxwdWdobndmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE4NDk5NzMsImV4cCI6MjA4NzQyNTk3M30.BwDOMJHDKPgOcQxsGXBXk8eiN7qVkswRL8GCTfWnXPk';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Upgraded System prompt instructing the AI that it has full access to query details
const SYSTEM_PROMPT = `You are a helpful and polite administrative AI assistant for the Ramadan Planner app dashboard.
You have access to real-time data and statistics from the Supabase database.
Your main job is to answer the user's questions in detail using the database contents, such as listing questions, summarizing community events, showing notices/ads, or showing member directories.

Rules:
1. You MUST answer all user questions in Bengali (Bangla) language, but you can use English names, numbers, or terminology where it makes sense.
2. You have FULL permission to view and list detailed contents (questions text, user names, roles, announcements, notices, events). If the user asks for details of questions or list of users, call the corresponding tools and present them clearly. Do not claim you don't have access or permission.
3. Be concise and format your responses nicely using Markdown. Use tables or lists to show multiple records.
4. If a question is not related to the database, answer politely in Bangla.`;

// Tools (Functions) descriptions for OpenAI
const tools = [
  {
    type: "function",
    function: {
      name: "get_qa_statistics",
      description: "Retrieve counts of total, answered, and unanswered questions in the community Q&A section.",
      parameters: { type: "object", properties: {} }
    }
  },
  {
    type: "function",
    function: {
      name: "get_questions_list",
      description: "Retrieve a list of all user questions asked in the community Q&A section, including question text, answer text, is_answered status, and the user name who asked.",
      parameters: { type: "object", properties: {} }
    }
  },
  {
    type: "function",
    function: {
      name: "get_events_summary",
      description: "Retrieve summary of community events including total count, counts by status (pending, approved, completed, etc.), and recent events.",
      parameters: { type: "object", properties: {} }
    }
  },
  {
    type: "function",
    function: {
      name: "get_events_list",
      description: "Retrieve a detailed list of all community event requests including event title, description, status, location, and requested date.",
      parameters: { type: "object", properties: {} }
    }
  },
  {
    type: "function",
    function: {
      name: "get_ads_and_notices_summary",
      description: "Retrieve statistics for promotional ads and notices/alerts.",
      parameters: { type: "object", properties: {} }
    }
  },
  {
    type: "function",
    function: {
      name: "get_ads_list",
      description: "Retrieve a list of all promotional advertisements including title, description, active status, and campaign dates.",
      parameters: { type: "object", properties: {} }
    }
  },
  {
    type: "function",
    function: {
      name: "get_notices_list",
      description: "Retrieve a list of all public notices and alerts including title, content text, category, and active status.",
      parameters: { type: "object", properties: {} }
    }
  },
  {
    type: "function",
    function: {
      name: "get_user_statistics",
      description: "Retrieve counts of registered user profiles grouped by their role (admin, imam, user, etc.).",
      parameters: { type: "object", properties: {} }
    }
  },
  {
    type: "function",
    function: {
      name: "get_members_list",
      description: "Retrieve a list of all registered member profiles including their full name, role (user, imam, admin, etc.), contact phone, and email.",
      parameters: { type: "object", properties: {} }
    }
  }
];

// Simple in-memory session store for lightweight context persistence
const sessions = new Map();

exports.handler = async function (event, context) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle preflight OPTIONS request
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const chatInput = body.chatInput;
    const sessionId = body.sessionId || 'default';

    if (!chatInput) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Missing chatInput parameter' })
      };
    }

    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'OpenAI API key is not configured in Netlify environment variables.' })
      };
    }

    // Retrieve or initialize session conversation history
    if (!sessions.has(sessionId)) {
      sessions.set(sessionId, [{ role: 'system', content: SYSTEM_PROMPT }]);
    }
    const history = sessions.get(sessionId);

    // Append user input
    history.push({ role: 'user', content: chatInput });

    // Call OpenAI Chat Completions API using the premium GPT-4o model
    let responseText = await runAgentLoop(apiKey, history);

    // Keep history clean and capped to avoid excessive token counts (max 50 messages)
    if (history.length > 50) {
      history.splice(1, history.length - 50);
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ output: responseText })
    };

  } catch (error) {
    console.error('Handler error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message || 'Internal Server Error' })
    };
  }
};

// Orchestrates the LLM function-calling loop
async function runAgentLoop(apiKey, history) {
  const openAiUrl = 'https://api.openai.com/v1/chat/completions';

  // Step 1: Initial call to OpenAI requesting model evaluation
  let response = await fetch(openAiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: 'gpt-4o', // Upgraded to premium model
      messages: history,
      tools: tools,
      tool_choice: 'auto'
    })
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`OpenAI API error: ${response.status} - ${errText}`);
  }

  let data = await response.json();
  let message = data.choices[0].message;

  // If the model does not request any tool calls, return its text content directly
  if (!message.tool_calls || message.tool_calls.length === 0) {
    history.push(message);
    return message.content || "আমি দুঃখিত, আমি আপনাকে সাহায্য করতে পারছি না।";
  }

  // Step 2: Handle tool/function calls
  history.push(message); // Save assistant's function request message

  for (const toolCall of message.tool_calls) {
    const functionName = toolCall.function.name;
    let toolResult;

    try {
      console.log(`Executing tool: ${functionName}`);
      if (functionName === 'get_qa_statistics') {
        toolResult = await getQaStatistics();
      } else if (functionName === 'get_questions_list') {
        toolResult = await getQuestionsList();
      } else if (functionName === 'get_events_summary') {
        toolResult = await getEventsSummary();
      } else if (functionName === 'get_events_list') {
        toolResult = await getEventsList();
      } else if (functionName === 'get_ads_and_notices_summary') {
        toolResult = await getAdsAndNoticesSummary();
      } else if (functionName === 'get_ads_list') {
        toolResult = await getAdsList();
      } else if (functionName === 'get_notices_list') {
        toolResult = await getNoticesList();
      } else if (functionName === 'get_user_statistics') {
        toolResult = await getUserStatistics();
      } else if (functionName === 'get_members_list') {
        toolResult = await getMembersList();
      } else {
        toolResult = { error: `Tool ${functionName} not found.` };
      }
    } catch (e) {
      console.error(`Tool execution error for ${functionName}:`, e);
      toolResult = { error: `Failed to fetch data: ${e.message}` };
    }

    // Append tool output back to conversation history
    history.push({
      role: 'tool',
      tool_call_id: toolCall.id,
      name: functionName,
      content: JSON.stringify(toolResult)
    });
  }

  // Step 3: Call OpenAI again to compile the final answer using the query results
  let finalResponse = await fetch(openAiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: 'gpt-4o', // Upgraded to premium model
      messages: history
    })
  });

  if (!finalResponse.ok) {
    const errText = await finalResponse.text();
    throw new Error(`OpenAI final call error: ${finalResponse.status} - ${errText}`);
  }

  let finalData = await finalResponse.json();
  let finalMessage = finalData.choices[0].message;
  history.push(finalMessage);

  return finalMessage.content;
}

// ── DATABASE QUERY IMPLEMENTATIONS ──

async function getQaStatistics() {
  const { data, error } = await supabase
    .from('community_qa')
    .select('is_answered');

  if (error) throw error;

  const total = data.length;
  const answered = data.filter(q => q.is_answered === true).length;
  const unanswered = total - answered;

  return { total, answered, unanswered };
}

async function getQuestionsList() {
  const { data, error } = await supabase
    .from('community_qa')
    .select('id, title, question, answer, is_answered, created_at, user_profile:profiles!community_qa_user_id_fkey(full_name)')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data.map(q => ({
    id: q.id,
    title: q.title,
    question: q.question,
    answer: q.answer,
    is_answered: q.is_answered,
    asked_by: q.user_profile ? q.user_profile.full_name : 'Unknown User',
    created_at: q.created_at
  }));
}

async function getEventsSummary() {
  const { data, error } = await supabase
    .from('event_requests')
    .select('status, title, requested_date');

  if (error) throw error;

  const total = data.length;
  const counts = {};
  data.forEach(e => {
    const status = e.status || 'pending';
    counts[status] = (counts[status] || 0) + 1;
  });

  // Get 5 recent events sorted descending by requested_date
  const recent = [...data]
    .sort((a, b) => new Date(b.requested_date) - new Date(a.requested_date))
    .slice(0, 5)
    .map(e => ({ title: e.title, status: e.status, date: e.requested_date }));

  return { total, counts, recent };
}

async function getEventsList() {
  const { data, error } = await supabase
    .from('event_requests')
    .select('id, title, description, status, location, requested_date, created_at')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

async function getAdsAndNoticesSummary() {
  const { count: adsCount, error: adsError } = await supabase
    .from('ads')
    .select('*', { count: 'exact', head: true });

  if (adsError) throw adsError;

  const { count: noticesCount, error: noticesError } = await supabase
    .from('notices')
    .select('*', { count: 'exact', head: true });

  if (noticesError) throw noticesError;

  return { adsCount, noticesCount };
}

async function getAdsList() {
  const { data, error } = await supabase
    .from('ads')
    .select('id, title, description, start_date, end_date, is_active, created_at')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

async function getNoticesList() {
  const { data, error } = await supabase
    .from('notices')
    .select('id, title, content, category, is_active, created_at')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

async function getUserStatistics() {
  const { data, error } = await supabase
    .from('profiles')
    .select('role');

  if (error) throw error;

  const total = data.length;
  const roles = {};
  data.forEach(p => {
    const role = p.role || 'user';
    roles[role] = (roles[role] || 0) + 1;
  });

  return { total, roles };
}

async function getMembersList() {
  const { data, error } = await supabase
    .from('profiles')
    .select('full_name, role, phone, email, created_at')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}
